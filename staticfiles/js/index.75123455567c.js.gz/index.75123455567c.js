import 'htmx.org';
import 'alpinejs';
// import '../css/tailwind.css';
import '../css/base.css';

