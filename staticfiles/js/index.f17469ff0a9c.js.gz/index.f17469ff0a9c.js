
import '../css/tailwind.css';
import '../css/base.css';
import Alpine from 'alpinejs';
import htmx from 'htmx.org';

// Initialize Alpine.js
window.Alpine = Alpine;
Alpine.start();




window.htmx = require('htmx.org');