
import '../css/tailwind.css';
import '../css/base.css';
import Alpine from 'alpinejs';

// Initialize Alpine.js
window.Alpine = Alpine;
Alpine.start();


